
package test;


import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import app.Login;

/**
 * LoginTest provides comprehensive testing for all Login class methods.
 */
public class LoginTest {

    // Common test data
    private final String VALID_USERNAME = "kyl_1";
    private final String VALID_PASSWORD = "Ch&&sec@ke99!";
    private final String VALID_PHONE = "+27838968976";
    private final String SUCCESS_MESSAGE = "Username successfully captured.\nPassword successfully captured.\nCell phone number successfully added.";

    @Test
    public void testUsernameIsCorrectlyFormatted() {
        Login testLogin = new Login("Kyle", "Smith", VALID_USERNAME, VALID_PASSWORD, VALID_PHONE);
        assertEquals(SUCCESS_MESSAGE, testLogin.registerUser());
    }

    @Test
    public void testUsernameIsIncorrectlyFormatted() {
        Login testLogin = new Login("Kyle", "Smith", "invalid", VALID_PASSWORD, VALID_PHONE);
        assertEquals("Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.", testLogin.registerUser());
    }

    @Test
    public void testPasswordMeetsComplexityRequirements() {
        Login testLogin = new Login("Kyle", "Smith", VALID_USERNAME, VALID_PASSWORD, VALID_PHONE);
        assertEquals(SUCCESS_MESSAGE, testLogin.registerUser());
    }

    @Test
    public void testPasswordDoesNotMeetComplexityRequirements() {
        Login testLogin = new Login("Kyle", "Smith", VALID_USERNAME, "weak", VALID_PHONE);
        assertEquals("Password is not correctly formatted, please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.", testLogin.registerUser());
    }

    @Test
    public void testCellPhoneNumberCorrectlyFormatted() {
        Login testLogin = new Login("Kyle", "Smith", VALID_USERNAME, VALID_PASSWORD, VALID_PHONE);
        assertEquals(SUCCESS_MESSAGE, testLogin.registerUser());
    }

    @Test
    public void testCellPhoneNumberIncorrectlyFormatted() {
        Login testLogin = new Login("Kyle", "Smith", VALID_USERNAME, VALID_PASSWORD, "invalid_phone");
        assertEquals("Cell phone number incorrectly formatted or does not contain international code.", testLogin.registerUser());
    }

    @Test
    public void testLoginSuccessful() {
        Login testLogin = new Login("Kyle", "Smith", VALID_USERNAME, VALID_PASSWORD, VALID_PHONE);
        assertTrue(testLogin.loginUser(VALID_USERNAME, VALID_PASSWORD));
    }

    @Test
    public void testLoginFailed() {
        Login testLogin = new Login("Kyle", "Smith", VALID_USERNAME, VALID_PASSWORD, VALID_PHONE);
        assertFalse(testLogin.loginUser("wrong", "wrong"));
    }

    @Test
    public void testUsernameCorrectlyFormattedBoolean() {
        Login testLogin = new Login("Kyle", "Smith", VALID_USERNAME, VALID_PASSWORD, VALID_PHONE);
        assertTrue(testLogin.checkUserName());
    }

    @Test
    public void testUsernameIncorrectlyFormattedBoolean() {
        Login testLogin = new Login("Kyle", "Smith", "bad", VALID_PASSWORD, VALID_PHONE);
        assertFalse(testLogin.checkUserName());
    }

    @Test
    public void testPasswordMeetsComplexityRequirementsBoolean() {
        Login testLogin = new Login("Kyle", "Smith", VALID_USERNAME, VALID_PASSWORD, VALID_PHONE);
        assertTrue(testLogin.checkPasswordComplexity());
    }

    @Test
    public void testPasswordDoesNotMeetComplexityRequirementsBoolean() {
        Login testLogin = new Login("Kyle", "Smith", VALID_USERNAME, "bad", VALID_PHONE);
        assertFalse(testLogin.checkPasswordComplexity());
    }

    @Test
    public void testCellPhoneNumberCorrectlyFormattedBoolean() {
        Login testLogin = new Login("Kyle", "Smith", VALID_USERNAME, VALID_PASSWORD, VALID_PHONE);
        assertTrue(testLogin.checkCellPhoneNumber());
    }

    @Test
    public void testCellPhoneNumberIncorrectlyFormattedBoolean() {
        Login testLogin = new Login("Kyle", "Smith", VALID_USERNAME, VALID_PASSWORD, "bad");
        assertFalse(testLogin.checkCellPhoneNumber());
    }
}