package test;

import app.Message;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class MessageTest {

    @Test
    public void testMessageLengthSuccess() {

        Message messageObj =
                new Message(
                        "0012345678",
                        0,
                        "+27718693002",
                        "Hi Mike, can you join us for dinner tonight?"
                );

        assertTrue(
                messageObj.checkMessageLength()
        );
    }

    @Test
    public void testMessageLengthFailure() {

        String longText =
                "A".repeat(260);

        Message messageObj =
                new Message(
                        "0012345678",
                        0,
                        "+27718693002",
                        longText
                );

        assertFalse(
                messageObj.checkMessageLength()
        );
    }

    @Test
    public void testRecipientNumberCorrectlyFormatted() {

        Message messageObj =
                new Message(
                        "0012345678",
                        0,
                        "+27718693002",
                        "Hi Mike, can you join us for dinner tonight?"
                );

        assertEquals(
                1,
                messageObj.checkRecipientCell()
        );
    }

    @Test
    public void testRecipientNumberIncorrectlyFormatted() {

        Message messageObj =
                new Message(
                        "0012345678",
                        0,
                        "08575975889",
                        "Hi Keegan, did you receive the payment?"
                );

        assertEquals(
                0,
                messageObj.checkRecipientCell()
        );
    }

    @Test
    public void testMessageHashCreatedCorrectly() {

        Message messageObj =
                new Message(
                        "0012345678",
                        0,
                        "+27718693002",
                        "Hi Mike, can you join us for dinner tonight?"
                );

        assertEquals(
                "00:0:HITONIGHT?",
                messageObj.getMessageHash()
        );
    }

    @Test
    public void testMessageIDCreated() {

        Message messageObj =
                new Message(
                        "0012345678",
                        0,
                        "+27718693002",
                        "Testing ID"
                );

        assertTrue(
                messageObj.checkMessageID()
        );
    }

    @Test
    public void testSendMessage() {

        Message messageObj =
                new Message(
                        "0012345678",
                        0,
                        "+27718693002",
                        "Testing send"
                );

        assertEquals(
                "Message successfully sent.",
                messageObj.sentMessage(1)
        );
    }

    @Test
    public void testDisregardMessage() {

        Message messageObj =
                new Message(
                        "0012345678",
                        0,
                        "+27718693002",
                        "Testing disregard"
                );

        assertEquals(
                "Press 0 to delete message.",
                messageObj.sentMessage(2)
        );
    }

    @Test
    public void testStoreMessage() {

        Message messageObj =
                new Message(
                        "0012345678",
                        0,
                        "+27718693002",
                        "Testing store"
                );

        assertEquals(
                "Message successfully stored.",
                messageObj.sentMessage(3)
        );
    }
}