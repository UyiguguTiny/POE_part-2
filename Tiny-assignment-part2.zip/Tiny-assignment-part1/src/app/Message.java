package app;

import java.io.FileWriter;
import java.io.IOException;

/**
 * Message class handles all message processing operations.
 */
public class Message {

    private String messageIdValue;
    private int messageCounter;
    private String recipientNumber;
    private String textMessage;
    private String generatedHash;

    private static int sentMessageTotal = 0;

    public Message(String messageIdValue, int messageCounter,
                   String recipientNumber, String textMessage) {

        this.messageIdValue = messageIdValue;
        this.messageCounter = messageCounter;
        this.recipientNumber = recipientNumber;
        this.textMessage = textMessage;

        this.generatedHash = createMessageHash();
    }

    public boolean checkMessageID() {
        return messageIdValue.length() == 10;
    }

    public int checkRecipientCell() {

        boolean validRecipient =
                recipientNumber.matches("^\\+27\\d{9}$");

        if (validRecipient) {
            return 1;
        }

        return 0;
    }

    public boolean checkMessageLength() {
        return textMessage.length() <= 250;
    }

    public String createMessageHash() {

        String[] splitWords =
                textMessage.trim().split("\\s+");

        String first =
                splitWords[0].toUpperCase();

        String last =
                splitWords[splitWords.length - 1].toUpperCase();

        return messageIdValue.substring(0, 2)
                + ":"
                + messageCounter
                + ":"
                + first
                + last;
    }

    public String sentMessage(int selectedOption) {

        switch (selectedOption) {

            case 1:
                sentMessageTotal++;
                return "Message successfully sent.";

            case 2:
                return "Press 0 to delete message.";

            case 3:
                storeMessage();
                return "Message successfully stored.";

            default:
                return "Invalid option selected.";
        }
    }

    public String printMessages() {

        return "Message ID: " + messageIdValue
                + "\nMessage Hash: " + generatedHash
                + "\nRecipient: " + recipientNumber
                + "\nMessage: " + textMessage;
    }

    public static int returnTotalMessages() {
        return sentMessageTotal;
    }

    public void storeMessage() {

        try {

            FileWriter file =
                    new FileWriter("storedMessages.json", true);

            file.write("{\n");
            file.write("\"MessageID\": \"" + messageIdValue + "\",\n");
            file.write("\"MessageHash\": \"" + generatedHash + "\",\n");
            file.write("\"Recipient\": \"" + recipientNumber + "\",\n");
            file.write("\"Message\": \"" + textMessage + "\"\n");
            file.write("}\n");

            file.close();

        } catch (IOException e) {

            System.out.println(
                    "Error writing to file."
            );
        }
    }

    public String getMessageHash() {
        return generatedHash;
    }

    public String getMessageIdValue() {
        return messageIdValue;
    }

    public String getRecipientNumber() {
        return recipientNumber;
    }

    public String getTextMessage() {
        return textMessage;
    }
}