package app;

import java.util.Random;
import java.util.Scanner;

/**
 * Main class runs the console-based registration and login application.
 */
public class Main {

    public static void main(String[] args) {

        Scanner scannerObject = new Scanner(System.in);

        System.out.println("===== REGISTRATION =====");

        System.out.print("Enter first name: ");
        String fName = scannerObject.nextLine();

        System.out.print("Enter last name: ");
        String lName = scannerObject.nextLine();

        System.out.print("Enter username: ");
        String uName = scannerObject.nextLine();

        System.out.print("Enter password: ");
        String pWord = scannerObject.nextLine();

        System.out.print("Enter South African cell phone number (include +27): ");
        String cellNumber = scannerObject.nextLine();

        Login loginInstance =
                new Login(fName, lName, uName, pWord, cellNumber);

        String registrationResult =
                loginInstance.registerUser();

        System.out.println(registrationResult);

        boolean usernameValidation =
                loginInstance.checkUserName();

        boolean passwordValidation =
                loginInstance.checkPasswordComplexity();

        boolean phoneValidation =
                loginInstance.checkCellPhoneNumber();

        if (usernameValidation
                && passwordValidation
                && phoneValidation) {

            System.out.println();
            System.out.println("===== LOGIN =====");

            System.out.print("Enter username: ");
            String loginUsernameInput =
                    scannerObject.nextLine();

            System.out.print("Enter password: ");
            String loginPasswordInput =
                    scannerObject.nextLine();

            String loginStatusOutput =
                    loginInstance.returnLoginStatus(
                            loginUsernameInput,
                            loginPasswordInput
                    );

            System.out.println(loginStatusOutput);

            if (loginInstance.loginUser(
                    loginUsernameInput,
                    loginPasswordInput)) {

                System.out.println();
                System.out.println("Welcome to QuickChat.");

                int menuChoice = 0;

                while (menuChoice != 3) {

                    System.out.println();
                    System.out.println("===== QUICKCHAT MENU =====");
                    System.out.println("1) Send Messages");
                    System.out.println("2) Show recently sent messages");
                    System.out.println("3) Quit");

                    System.out.print("Choose option: ");

                    menuChoice = scannerObject.nextInt();
                    scannerObject.nextLine();

                    switch (menuChoice) {

                        case 1:

                            System.out.print(
                                    "How many messages would you like to send? "
                            );

                            int totalMessages =
                                    scannerObject.nextInt();

                            scannerObject.nextLine();

                            for (int loopCounter = 1;
                                 loopCounter <= totalMessages;
                                 loopCounter++) {

                                System.out.println();
                                System.out.println(
                                        "===== MESSAGE "
                                                + loopCounter
                                                + " ====="
                                );

                                String generatedID =
                                        generateMessageID();

                                System.out.println(
                                        "Generated Message ID: "
                                                + generatedID
                                );

                                System.out.print(
                                        "Enter recipient number: "
                                );

                                String recipientInput =
                                        scannerObject.nextLine();

                                System.out.print(
                                        "Enter your message: "
                                );

                                String messageInput =
                                        scannerObject.nextLine();

                                Message msg =
                                        new Message(
                                                generatedID,
                                                loopCounter,
                                                recipientInput,
                                                messageInput
                                        );

                                if (!msg.checkMessageID()) {

                                    System.out.println(
                                            "Message ID invalid."
                                    );

                                    continue;
                                }

                                if (msg.checkRecipientCell() == 1) {

                                    System.out.println(
                                            "Cell phone number successfully captured."
                                    );

                                } else {

                                    System.out.println(
                                            "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again."
                                    );

                                    continue;
                                }

                                if (msg.checkMessageLength()) {

                                    System.out.println(
                                            "Message ready to send."
                                    );

                                } else {

                                    int extraCharacters =
                                            messageInput.length() - 250;

                                    System.out.println(
                                            "Message exceeds 250 characters by "
                                                    + extraCharacters
                                                    + ", please reduce the size."
                                    );

                                    continue;
                                }

                                System.out.println();
                                System.out.println("1) Send Message");
                                System.out.println("2) Disregard Message");
                                System.out.println("3) Store Message");

                                System.out.print(
                                        "Select option: "
                                );

                                int option =
                                        scannerObject.nextInt();

                                scannerObject.nextLine();

                                System.out.println(
                                        msg.sentMessage(option)
                                );

                                System.out.println();
                                System.out.println(
                                        "===== MESSAGE DETAILS ====="
                                );

                                System.out.println(
                                        msg.printMessages()
                                );
                            }

                            System.out.println();
                            System.out.println(
                                    "Total messages sent: "
                                            + Message.returnTotalMessages()
                            );

                            break;

                        case 2:

                            System.out.println(
                                    "Coming Soon."
                            );

                            break;

                        case 3:

                            System.out.println(
                                    "Closing QuickChat."
                            );

                            break;

                        default:

                            System.out.println(
                                    "Invalid menu option selected."
                            );
                    }
                }
            }
        }

        scannerObject.close();
    }

    public static String generateMessageID() {

        Random randomObject = new Random();

        long randomNumber =
                1000000000L
                        + (long) (
                        randomObject.nextDouble()
                                * 9000000000L
                );

        return String.valueOf(randomNumber);
    }
}